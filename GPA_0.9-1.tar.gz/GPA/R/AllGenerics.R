
# generic methods for "GPA" class

setGeneric( "fdr",
    function( object, ... )
    standardGeneric("fdr")
)

setGeneric( "assoc",
    function( object, ... )
    standardGeneric("assoc")
)

setGeneric( "cov",
    function( object, ... )
    standardGeneric("cov")
)

setGeneric( "estimates",
    function( object, ... )
    standardGeneric("estimates")
)


# generic methods for "GPA" class

setGeneric( "cov",
    function( object, ... )
    standardGeneric("cov")
)

setGeneric( "estimates",
    function( object, ... )
    standardGeneric("estimates")
)

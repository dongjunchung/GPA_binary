
# bin-level data

setClass( Class="GPA",
    representation=representation(
        fit="list",
		setting="list",
        gwasPval="matrix",
        annMat="matrix"
    )
)
